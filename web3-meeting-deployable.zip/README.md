# Web3 Meeting — One-click deploy demo

This repository contains a Web3 meeting demo (wallet login + LiveKit + Host controls) prepared to be deployed via GitHub Actions.

## Quickstart (local)
1. unzip and run:
```bash
docker-compose up
```
2. Visit http://localhost

## One-click deploy via GitHub Actions
1. Create GitHub repo and push this project.
2. Add repository Secrets:
- DOCKERHUB_USERNAME
- DOCKERHUB_TOKEN
- SSH_PRIVATE_KEY
- SSH_HOST
- SSH_USER
- REMOTE_COMPOSE_DIR

3. Push to `main` — Actions will build images and deploy to your server.

## Important
- Implement SIWE verification before production.
- Use TLS, TURN, and secure LiveKit configuration.
