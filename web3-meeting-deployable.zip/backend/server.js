import express from "express";
import cors from "cors";
import bodyParser from "body-parser";
import { AccessToken } from "livekit-server-sdk";

const app = express();
app.use(cors());
app.use(bodyParser.json());

const LIVEKIT_URL = process.env.LIVEKIT_URL || "ws://livekit:7880";
const LIVEKIT_API_KEY = process.env.LIVEKIT_API_KEY || "devkey";
const LIVEKIT_API_SECRET = process.env.LIVEKIT_API_SECRET || "secret";

app.post('/siwe/verify', (req, res) => {
  const { message, signature, address } = req.body;
  if (!message || !signature || !address) return res.status(400).json({ error: 'message, signature, address required' });
  // TODO: verify SIWE message & signature using @spruceid/siwe
  const token = Buffer.from(JSON.stringify({ address, iat: Date.now() })).toString('base64');
  res.json({ accessToken: token, address });
});

function requireAddress(req, res, next) {
  const address = req.body.address || req.query.address;
  if (!address) return res.status(400).json({ error: 'address required' });
  next();
}

app.post("/create-room", requireAddress, (req, res) => {
  const { roomName, address } = req.body;
  if (!roomName || !address) return res.status(400).send("params required");

  const at = new AccessToken(LIVEKIT_API_KEY, LIVEKIT_API_SECRET, {
    identity: address,
    ttl: "10m",
  });
  at.addGrant({
    roomJoin: true,
    room: roomName,
    canPublish: true,
    canSubscribe: true,
  });

  res.json({ roomName, token: at.toJwt(), url: LIVEKIT_URL });
});

app.post("/join-room", requireAddress, (req, res) => {
  const { roomName, address } = req.body;
  if (!roomName || !address) return res.status(400).send("params required");

  const at = new AccessToken(LIVEKIT_API_KEY, LIVEKIT_API_SECRET, {
    identity: address,
    ttl: "10m",
  });
  at.addGrant({
    roomJoin: true,
    room: roomName,
    canPublish: true,
    canSubscribe: true,
  });

  res.json({ roomName, token: at.toJwt(), url: LIVEKIT_URL });
});

app.listen(3001, () => console.log("Backend running on :3001"));
