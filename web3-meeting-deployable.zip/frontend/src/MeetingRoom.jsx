import { Room, RoomEvent } from "livekit-client";
import { useEffect, useRef, useState } from "react";
export default function MeetingRoom({ meeting }) {
  const videoEl = useRef(null);
  const [status, setStatus] = useState('connecting');
  useEffect(()=> {
    const room = new Room();
    (async ()=> {
      try {
        await room.connect(meeting.url, meeting.token);
        setStatus('connected');
        room.on(RoomEvent.TrackSubscribed, (track)=> {
          if (track.kind==='video' && videoEl.current) track.attach(videoEl.current);
        });
        await room.localParticipant.enableCameraAndMicrophone();
      } catch(e) { console.error(e); setStatus('error'); }
    })();
    return ()=> room.disconnect();
  }, [meeting]);
  return (<div><h3>会议室：{meeting.roomName}</h3><div>Status: {status}</div><video ref={videoEl} autoPlay playsInline style={{width:640,height:360,background:'#000'}}></video></div>);
}
