import { ethers } from "ethers";
export default function WalletLogin({ onLogin }) {
  const connectWallet = async () => {
    if (!window.ethereum) return alert("请安装 MetaMask");
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    await provider.send('eth_requestAccounts', []);
    const signer = provider.getSigner();
    const addr = await signer.getAddress();
    onLogin(addr);
  };
  return <button onClick={connectWallet}>用钱包登录</button>;
}
