import { useState } from "react";
import WalletLogin from "./WalletLogin";
import MeetingRoom from "./MeetingRoom";
function App() {
  const [address, setAddress] = useState(null);
  const [meeting, setMeeting] = useState(null);
  return (
    <div style={{padding:20}}>
      {!address ? (
        <WalletLogin onLogin={setAddress} />
      ) : !meeting ? (
        <div>
          <h2>欢迎 {address}</h2>
          <input id="roomName" placeholder="room name" />
          <button onClick={async ()=>{ const roomName=document.getElementById('roomName').value||'testRoom'; const res=await fetch((import.meta.env.VITE_API_BASE||'http://localhost:3001')+'/create-room',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({roomName,address})}).then(r=>r.json()); setMeeting(res);}}>发起会议</button>
          <button onClick={async ()=>{ const roomName=document.getElementById('roomName').value||'testRoom'; const res=await fetch((import.meta.env.VITE_API_BASE||'http://localhost:3001')+'/join-room',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({roomName,address})}).then(r=>r.json()); setMeeting(res);}} style={{marginLeft:8}}>加入会议</button>
        </div>
      ) : <MeetingRoom meeting={meeting} address={address} /> }
    </div>
  );
}
export default App;
